<!doctype html>
<html lang="en">
  <head>
    <title>Me &mdash; Website Template by Colorlib</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Arbutus+Slab|Open+Sans:300,400,700" rel="stylesheet">
    <link rel="stylesheet" href="assets/fonts/icomoon/style.css">

    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/jquery-ui.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="assets/css/owl.theme.default.min.css">

    <link rel="stylesheet" href="assets/css/jquery.fancybox.min.css">

    <link rel="stylesheet" href="assets/css/bootstrap-datepicker.css">

    <link rel="stylesheet" href="assets/fonts/flaticon/font/flaticon.css">

    <link rel="stylesheet" href="assets/css/aos.css">

    <link rel="stylesheet" href="assets/css/style.css">
    
  </head>
  <body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">
  


  <div class="site-wrap">

    <div class="site-mobile-menu site-navbar-target">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>
   
    <header class="site-navbar py-4 js-sticky-header site-navbar-target" role="banner">

      <div class="container-fluid">
        <div class="row align-items-center justify-content-center">
          
          <div class="">
            <nav class="site-navigation position-relative text-right" role="navigation">
              <ul class="site-menu main-menu js-clone-nav mr-auto d-none d-lg-block">
                <li><a href="#home-section" class="nav-link">Home</a></li>
                <li><a href="#services-section" class="nav-link">Biodata</a></li>
                <li><a href="#about-section" class="nav-link">About</a></li>
                
              </ul>
            </nav>
          </div>


          <div class="text-left">

            <nav class="site-navigation position-relative" role="navigation">
              <ul class="site-menu main-menu js-clone-nav mr-auto d-none d-lg-block">
                <li><a href="#clients-section" class="nav-link">Client</a></li>
                <li><a href="#contact-section" class="nav-link">Contact</a></li>
              </ul>
            </nav>


            <div class="d-inline-block d-lg-none" style="position: relative; top: 3px;"><a href="#" class="site-menu-toggle js-menu-toggle float-right"><span class="icon-menu h3"></span></a></div>

          </div>

        </div>
      </div>
      
    </header>


    <div class="site-blocks-cover overlay bg-light" id="home-section">

      <div class="container">
        <div class="row justify-content-center">

          <div class="col-md-12 mt-lg-5 text-left align-self-center text-intro">
            <div class="row">
              <div class="col-lg-6">
                <h1 class="text-black">Fajar Permana Putra</h1>
                <p class="lead">I'M JAY</p>

              </div>
            </div>
          </div>
            
        </div>
      </div>

      <img src="assets/images/face.png" alt="Image" class="img-face" data-aos="fade">

      
    </div>  

    

    
    <div class="site-section" id="services-section">
      <div class="container">
        <div class="row ">
          <div class="col-12 mb-5 position-relative">
            <h2 class="section-title text-center mb-5">BIODATA AING</h2>
          </div>
          
          <div class="col-md-6 mb-4">
            <div class="service d-flex h-100">
              <div class="service-number mr-4"><span class="icon-style"></span></div>
              <div class="service-about">
                <h3>NAMA</h3>
                <p>Fajar Permana Putra</p>
              </div>
            </div>
          </div>

          <div class="col-md-6 mb-4">
            <div class="service d-flex h-100">
              <div class="service-number mr-4"><span class="icon-business_center"></span></div>
              <div class="service-about">
                <h3>Alamat</h3>
                <p>JL. Geger Arum Baru</p>
              </div>
            </div>
          </div>

          <div class="col-md-6 mb-4">
            <div class="service d-flex h-100">
              <div class="service-number mr-4"><span class="icon-desktop_windows"></span></div>
              <div class="service-about">
                <h3>JENIS KELAMIN</h3>
                <p>Laki-Laki</p>
              </div>
            </div>
          </div>

          <div class="col-md-6 mb-4">
            <div class="service d-flex h-100">
              <div class="service-number mr-4"><span class="icon-layers"></span></div>
              <div class="service-about">
                <h3>PENDIDIKAN</h3>
                <p> SDSN 1 Ciburuy </p>
				<p> SMPN 1 Padalarang </p>
				<p> SMK AL FALAH</p>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>

    <div class="site-section" id="about-section">
      <div class="container">
        <div class="row ">
          <div class="col-12 mb-4 position-relative">
            <h2 class="section-title">TENTANG SAYA</h2>
          </div>
          <div class="col-lg-4 order-1 order-lg-2 mb-4 mb-lg-0">
            <div class="bg-light pt-5">
            <img src="assets/images/f.jpg" alt="Image" class="img-fluid">
            </div>
          </div>
          <div class="col-lg-4 order-2 order-lg-1">
            <p>Nama saya N'Douassell Tinggal di Bandung. Saya bermain di Tim Persib Bandung.</p>
            <p>Saya Lahir di Chad, 24 Januari 2002.</p>
          </div>
          <div class="col-lg-4 order-3 order-lg-3">
            <p> No Telepon Saya 089670173435 </p>
            <p> WADADAW </p>
            <p><a href="#contact-section" class="btn smoothscroll btn-primary">Contact Me</a></p>
          </div>
          
        </div>
      </div>
    </div>



    <section class="site-section bg-dark">
      <div class="container">
        <div class="row">
          <div class="col-12 mb-5 position-relative">
            <h2 class="section-title text-center mb-5 text-white">testimonials</h2>
          </div>
        </div>
        <div class="owl-carousel slide-one-item">
          <div class="slide">
            <blockquote>
              <p>HARTA YANG PALING BERHARGA ADALAH RUMAH WARGA </p>
              <p><cite>&mdash; Mang Codet</cite></p>
            </blockquote>
          </div>
          <div class="slide">
            <blockquote>
              <p> ULAH KUMEOK SAMEMEH DI PACOK </p>
              <p><cite>&mdash; Bobotoh</cite></p>
            </blockquote>
          </div>
          <div class="slide">
            <blockquote>
              <p> CIGADUNG ( CINTA GADIS BERKERUDUNG ) </p>
              <p><cite>&mdash; Aqsal </cite></p>
            </blockquote>
          </div>
        </div>
      </div>
    </section>

    <section class="site-section"  id="clients-section">
      <div class="container">
        <div class="row">
          <div class="col-12 mb-5 position-relative">
            <h2 class="section-title text-center">Clients</h2>
          </div>
          <div class="col-6 col-sm-6 col-md-4 col-lg-4 text-center">
            <img src="assets/images/logo_1.jpg" alt="Image" class="img-fluid">
          </div>
          <div class="col-6 col-sm-6 col-md-4 col-lg-4 text-center">
            <img src="assets/images/logo_2.jpg" alt="Image" class="img-fluid">
          </div>
          <div class="col-6 col-sm-6 col-md-4 col-lg-4 text-center">
            <img src="assets/images/logo_3.jpg" alt="Image" class="img-fluid">
          </div>
          <div class="col-6 col-sm-6 col-md-4 col-lg-4 text-center">
            <img src="assets/images/logo_4.jpg" alt="Image" class="img-fluid">
          </div>      

          
          <div class="col-6 col-sm-6 col-md-4 col-lg-4 text-center">
            <img src="assets/images/logo_5.jpg" alt="Image" class="img-fluid">
          </div> 
          <div class="col-6 col-sm-6 col-md-4 col-lg-4 text-center">
            <img src="assets/images/logo_6.jpg" alt="Image" class="img-fluid">
          </div> 
        </div>
      </div>
    </section>

    

    <section class="site-section" id="contact-section">
      <div class="container">
        <div class="row">
          <div class="col-12 mb-5 position-relative">
            <h2 class="section-title text-center mb-5">Contact Form</h2>
          </div>
        </div>
        <form action="#" class="form">
          <div class="row mb-4">
            <div class="form-group col-6">
              <input type="text" class="form-control" placeholder="First name">
            </div>
            <div class="form-group col-6">
              <input type="text" class="form-control" placeholder="Last name">
            </div>
          </div>

          <div class="row mb-4">
            <div class="form-group col-12">
              <input type="email" class="form-control" placeholder="Email address">
            </div>
          </div>

          <div class="row mb-4">
            <div class="form-group col-12">
              <input type="text" class="form-control" placeholder="Subject of the message">
            </div>
          </div>

          <div class="row mb-4">
            <div class="form-group col-12">
              <textarea name="" id="" cols="30" rows="10" class="form-control" placeholder="Type your message here.."></textarea>
            </div>
          </div>

          <div class="row">
            <div class="col-md-6">
              <input type="submit" class="btn btn-primary" value="Send Message">
            </div>
          </div>
          
        </form>
      </div>
    </section>

  

  </div> <!-- .site-wrap -->

  <script src="assets/js/jquery-3.3.1.min.js"></script>
  <script src="assets/js/jquery-ui.js"></script>
  <script src="assets/js/popper.min.js"></script>
  <script src="assets/js/bootstrap.min.js"></script>
  <script src="assets/js/owl.carousel.min.js"></script>
  <script src="assets/js/jquery.easing.1.3.js"></script>
  <script src="assets/js/aos.js"></script>
  <script src="assets/js/jquery.fancybox.min.js"></script>
  <script src="assets/js/jquery.sticky.js"></script>
  <script src="assets/js/isotope.pkgd.min.js"></script>

  
  <script src="assets/js/main.js"></script>
    
  </body>
</html>